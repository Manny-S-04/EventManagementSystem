package JavaAssessment;

import java.io.Serializable;

public class Event implements Serializable {

    private String eventName;
    private String date;
    private String time;
    private String location;

    // Parameterised constructor
    public Event(String eventName, String date, String time, String location) {

        this.eventName = eventName.toLowerCase();
        this.date = date;
        this.time = time;
        this.location = location;
    }

    public Event() {
    }

    // Getter methods

    public String getEventName() {

        return this.eventName;
    }

    public String getDate() {

        return this.date;
    }

    public String getTime() {

        return this.time;
    }

    public String getLocation() {

        return this.location;
    }

    // Setters

    public void setEventName(String eventName) {

        this.eventName = eventName;
    }

    public void setDate(String date) {

        this.date = date;
    }

    public void setTime(String time) {

        this.time = time;
    }

    public void setLocation(String location) {

        this.location = location;
    }

    @Override
    public String toString() {

        return "Event Name: " + eventName + "\n" + "Date: " + date + "\n" + "Time: " + time + "\n" + "Location: "
                + location;
    }

}
