/**
 * A menu driven Command based Event Management System
 * The app runs on a do while menu which asks for user input and gives the following options:
 * "1: List all events"
 * "2: List an event's details"
 * "3: Edit an event"
 * "4: Add an event"
 * "5: Delete an event"
 * "6: List all attendees attending an event"
 * "7: Add attendee"
 * "8: Delete attendee"
 * "9: Quit"
 * 
 * listEvents()
 * 
 * Displays a list of all events currently stored in the system.
 * The method first checks if the events.ser file exists; if it does not, a new file is created.
 * If the file is empty or contains no events, a message is displayed indicating that the file is empty.
 * If events are found in the file, they are deserialized and displayed in a list format,
 * showing the name of each event.
 * 
 * 
 * listOneEvent()
 * 
 * Prompts the user to enter the name of an event to display.
 * If the specified event is found in the events.ser file, its details are displayed,
 * including its name, date, time, and location. If the specified event is not found,
 * a message is displayed indicating that the event could not be found.
 * @param sc a Scanner object used to obtain input from the user
 * 
 * editEvent()
 * 
 * Allows the user to edit an existing event by specifying which attributes to modify.
 * The user is first prompted to enter the name of the event to edit. If the specified event is found
 * in the events.ser file, the user is then prompted to select which attributes to modify
 * (event name, date, time, or location). The user can select multiple attributes to modify.
 * Once the user has finished selecting attributes, the new values are prompted for and applied
 * to the Event object. The EventDetails object is then updated with the new Event object,
 * and the HashMap containing the events is serialized and written to the events.ser file.
 * @param sc a Scanner object used to obtain input from the user
 * 
 * addEvent()
 * 
 * Adds a new event to the system by prompting the user for information.
 * The user is prompted to enter the event's name, date, time, and location.
 * This information is then used to create a new Event object, which is stored in a HashMap
 * along with its corresponding EventDetails object. The HashMap is then serialized
 * and written to the events.ser file.
 * @param sc a Scanner object used to obtain input from the user
 * 
 * deleteEvent()
 * 
 * This method deletes an event from the HashMap of events stored in a serialized file.
 * @param sc Scanner object used to receive input from the user.
 * 
 * listAttendees()
 * 
 * Lists all attendees of a specified event by prompting the user to enter the event name.
 * Retrieves the attendees from the serialized events file using the {@code deSerializeEvent}
 * method of the {@code Serializer} class and prints them to the console.
 * @param sc A scanner object used to get input from the user.
 * @throws NullPointerException if the specified event name is not found in the serialized events file.
 *  
 * addAttendee()
 * 
 * Adds a new attendee to an existing event. The method prompts the user to enter the name, age, email, and location of the attendee
 * and adds the attendee to the specified event in the serialized HashMap of events. The updated HashMap is then serialized back
 * to the events.ser file.
 * @param sc a Scanner object used to obtain user input
 * 
 * deleteAttendee()
 * 
 * This method allows the user to delete an attendee from an event. It prompts the user to input the name of the event
 * and the name of the attendee they want to delete. If the event is found in the events file, it will search for the
 * attendee in the attendees list of the event and remove it if it exists. It will then serialize the updated events list
 * back to the events file.
 * @param sc Scanner object used to get user input 
 *  
 *  
 */

package JavaAssessment;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class EventManager {

    public static void main(String[] args) {

        displayMenu();

    }

    public static void displayMenu() {

        // Initialize variables
        int choice = 0;
        Scanner sc = new Scanner(System.in);

        // Loop until user chooses to quit
        do {

            // Display menu options
            System.out.println("**************************");
            System.out.println("\nPlease select an option!\n");
            System.out.println("1: List all events");
            System.out.println("2: List an event's details");
            System.out.println("3: Edit an event");
            System.out.println("4: Add an event");
            System.out.println("5: Delete an event");
            System.out.println("6: List all attendees attending an event");
            System.out.println("7: Add attendee");
            System.out.println("8: Delete attendee");
            System.out.println("9: Quit\n");

            try {
                // Get user's choice and convert to integer
                choice = Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                // If input cannot be converted to integer, display error message and continue
                // loop
                System.out.println("That's not a valid choice! Try again!");
                continue;
            }

            // Handle user's choice
            switch (choice) {
                case 1:
                    // List all events
                    listEvents();
                    break;
                case 2:
                    // List details of a specific event
                    System.out.println("");
                    listOneEvent(sc);
                    break;
                case 3:
                    // Edit an existing event
                    System.out.println("");
                    editEvent(sc);
                    break;
                case 4:
                    // Add a new event
                    System.out.println("");
                    addEvent(sc);
                    break;
                case 5:
                    // Delete an existing event
                    System.out.println("");
                    deleteEvent(sc);
                    break;
                case 6:
                    // List all attendees of a specific event
                    System.out.println("");
                    listAttendees(sc);
                    break;
                case 7:
                    // Add a new attendee to an event
                    System.out.println("");
                    addAttendees(sc);
                    break;
                case 8:
                    // Delete an attendee from an event
                    System.out.println("");
                    deleteAttendee(sc);
                    break;
                case 9:
                    // Quit the program
                    System.out.println("bye");
                    break;
            }

        } while (choice != 9);

        // Close the scanner
        sc.close();

    }

    public static void listEvents() {

        // Code to check if the file exists
        // If the file does not exist it creates a new one
        File eventsFile = new File("events.ser");
        if (!eventsFile.exists()) {
            try {
                wait("File doesn't exist, creating a new one...");
                eventsFile.createNewFile();
            } catch (IOException e) {
                System.out.println(e);
            }
        }

        else {

            // creates events hashmap and iterators through the keys
            try {

                HashMap<String, EventDetails> events = Serializer.deSerializeEvent(eventsFile);

                Iterator<Map.Entry<String, EventDetails>> it = events.entrySet().iterator();

                while (it.hasNext()) {

                    Map.Entry<String, EventDetails> entry = it.next();
                    System.out.println("Event :" + entry.getKey() + "\n");

                }

            } catch (NullPointerException e) {
                System.out.println("File is empty...");
                return;
            }
        }

    }

    public static void listOneEvent(Scanner sc) {

        File eventsFile = new File("events.ser");
        if (!eventsFile.exists()) {
            try {
                wait("File doesn't exist, creating a new one...");
                eventsFile.createNewFile();
            } catch (IOException e) {
                System.out.println(e);
            }

        }

        // Matches userinput with key and prints out associateds Event object
        try {

            HashMap<String, EventDetails> events = Serializer.deSerializeEvent(eventsFile);

            System.out.println("What is the event's name?");
            String eventName = sc.nextLine();

            boolean eventFound = false;
            for (Map.Entry<String, EventDetails> entry : events.entrySet()) {
                String key = entry.getKey();
                EventDetails value = entry.getValue();

                if (key.equalsIgnoreCase(eventName)) {

                    System.out.println(value.getEvent());
                    eventFound = true;
                    return;

                }
            }
            if (!eventFound) {
                System.out.println("Event doesnt exist");
            }

        } catch (NullPointerException e) {

            System.out.println(e);
        }

    }

    public static void editEvent(Scanner sc) {

        File eventsFile = new File("events.ser");
        if (!eventsFile.exists()) {
            try {
                wait("File doesn't exist, creating a new one...");
                eventsFile.createNewFile();
            } catch (IOException e) {
                System.out.println(e);
            }

        }

        // Creates a new Event object and replaces it with the old one with a matching
        // key
        try {

            HashMap<String, EventDetails> events = Serializer.deSerializeEvent(eventsFile);

            System.out.println("What is the event's name?");
            String eventName = sc.nextLine();

            for (Map.Entry<String, EventDetails> entry : events.entrySet()) {
                String key = entry.getKey();
                EventDetails value = entry.getValue();

                if (key.equalsIgnoreCase(eventName)) {

                    Event e = value.getEvent();

                    System.out.println("Which elements would you like to edit?");
                    System.out.println("1 = Event Name \n2 = Date \n3 = Time \n4 = Location \n5 = Exit");

                    ArrayList<Integer> edits = new ArrayList<>();

                    while (true) {
                        System.out.println("Please choose 1 to 4:");
                        int inp1 = sc.nextInt();
                        sc.nextLine();
                        edits.add(inp1);
                        System.out.println("Do you want to continue adding items to change?");
                        System.out.println("Y/N");
                        String userinp = sc.nextLine();
                        if (userinp.equalsIgnoreCase("y")) {
                            continue;
                        } else if (userinp.equalsIgnoreCase("n")) {
                            break;
                        } else {
                            System.out.println("Please enter y or n");
                            continue;
                        }

                    }
                    Iterator<Integer> it = edits.iterator();

                    while (it.hasNext()) {
                        int pointer = it.next();

                        switch (pointer) {
                            case 1:
                                System.out.println("Please enter a new name:");
                                String name = sc.nextLine();
                                e.setEventName(name);
                                break;
                            case 2:
                                System.out.println("Please enter a new date:");
                                String date = sc.nextLine();
                                e.setDate(date);
                                break;
                            case 3:
                                System.out.println("Please enter a new time:");
                                String time = sc.nextLine();
                                e.setTime(time);
                                break;
                            case 4:
                                System.out.println("Please enter a new location:");
                                String location = sc.nextLine();
                                e.setLocation(location);
                                break;
                            case 5:
                                break;
                            default:
                                System.out.println("Invalid input");
                                editEvent(sc);
                        }

                    }
                    System.out.println("Are you happy with this edit? y/n");
                    System.out.println(e.toString());
                    String happy = sc.nextLine();

                    if (happy.equalsIgnoreCase("y")) {

                        value.setEvent(e);
                        events.remove(key, value);
                        events.put(e.getEventName().toLowerCase(), value);
                        Serializer.serializeEvent(eventsFile, events);
                    } else {
                        return;
                    }

                }
            }

        } catch (NullPointerException e) {

            System.out.println(e);
        }

    }

    public static void addEvent(Scanner sc) {

        File eventsFile = new File("events.ser");
        if (!eventsFile.exists()) {
            try {
                wait("File doesn't exist, creating a new one...");
                eventsFile.createNewFile();
            } catch (IOException e) {
                System.out.println(e);
            }

        }

        // Creates a new events object and stores it
        try {

            HashMap<String, EventDetails> events = Serializer.deSerializeEvent(eventsFile);

            if (events == null) {
                events = new HashMap<String, EventDetails>();
            }

            System.out.println("What is the event's name?");
            String eventName = sc.nextLine();
            System.out.println("Enter the date YYYY-MM-DD");
            String date = sc.nextLine();
            System.out.println("Enter the time HH:mm");
            String time = sc.nextLine();
            System.out.println("Enter the location");
            String location = sc.nextLine();

            Event event = new Event(eventName, date, time, location);
            EventDetails ed = new EventDetails(event);

            wait("Adding event...");
            events.put(eventName.toLowerCase(), ed);

            Serializer.serializeEvent(eventsFile, events);
            System.out.println("Done!");

        } catch (NullPointerException e) {
            System.out.println(e);
        }

    }

    public static void deleteEvent(Scanner sc) {

        File eventsFile = new File("events.ser");
        if (!eventsFile.exists()) {
            try {
                wait("File doesn't exist, creating a new one...");
                eventsFile.createNewFile();
            } catch (IOException e) {
                System.out.println(e);
            }

        }

        // Matches userinput with key and deletes associates events object
        try {

            HashMap<String, EventDetails> events = Serializer.deSerializeEvent(eventsFile);

            System.out.println("What is the event's name?");
            String eventName = sc.nextLine();

            Iterator<Map.Entry<String, EventDetails>> iterator = events.entrySet().iterator();

            while (iterator.hasNext()) {
                Map.Entry<String, EventDetails> entry = iterator.next();
                String key = entry.getKey();

                if (key.equalsIgnoreCase(eventName)) {
                    iterator.remove();
                    Serializer.serializeEvent(eventsFile, events);
                    wait("Event has been deleted...");
                    return;
                }
            }
            System.out.println("Event not found.");
        } catch (NullPointerException e) {
            System.out.println(e);
        }

    }

    public static void listAttendees(Scanner sc) {

        File eventsFile = new File("events.ser");
        if (!eventsFile.exists()) {
            try {
                wait("File doesn't exist, creating a new one...");
                eventsFile.createNewFile();
            } catch (IOException e) {
                System.out.println(e);
            }

        }

        // Same as the listevents method but prints associated attendees list
        try {

            HashMap<String, EventDetails> events = Serializer.deSerializeEvent(eventsFile);

            System.out.println("What is the event's name?");
            String eventName = sc.nextLine();

            for (Map.Entry<String, EventDetails> entry : events.entrySet()) {
                String key = entry.getKey();
                EventDetails value = entry.getValue();

                if (key.equalsIgnoreCase(eventName)) {

                    for (Attendee item : value.getAttendees()) {

                        if (value.getAttendees().isEmpty()) {
                            System.out.println("There are no attendees");
                        }

                        System.out.println(item.getName());

                    }

                }
            }
        } catch (NullPointerException e) {
            System.out.println(e);
        }

    }

    public static void addAttendees(Scanner sc) {

        File eventsFile = new File("events.ser");
        if (!eventsFile.exists()) {
            try {
                wait("File doesn't exist, creating a new one...");
                eventsFile.createNewFile();
            } catch (IOException e) {
                System.out.println(e);
            }

        }

        try {

            HashMap<String, EventDetails> events = Serializer.deSerializeEvent(eventsFile);
            if (events == null) {
                events = new HashMap<String, EventDetails>();
            }

            System.out.println("What is the event's name?");
            String eventName = sc.nextLine();

            for (Map.Entry<String, EventDetails> entry : events.entrySet()) {
                String key = entry.getKey();
                EventDetails value = entry.getValue();

                if (key.equalsIgnoreCase(eventName)) {

                    System.out.println("What is the attendees name?");
                    String name = sc.nextLine();
                    System.out.println("Enter the age");
                    String agestr = sc.nextLine();
                    int age = 0;
                    try {
                        age = Integer.parseInt(agestr);
                    } catch (NumberFormatException e) {
                        System.out.println(e);
                        System.out.println("Please write a number, age set to 0");
                    }
                    System.out.println("Enter the email");
                    String email = sc.nextLine();
                    System.out.println("Enter the location");
                    String number = sc.nextLine();

                    Attendee attendee = new Attendee(name, age, email, number);
                    Event event = value.getEvent();
                    ArrayList<Attendee> attendees = value.getAttendees();
                    attendees.add(attendee);
                    EventDetails ed = new EventDetails(event, attendees);

                    wait("Adding attendee...");
                    events.remove(eventName);
                    events.put(eventName.toLowerCase(), ed);

                    Serializer.serializeEvent(eventsFile, events);
                    System.out.println("Done!");
                    break;

                }

            }
        } catch (NullPointerException e) {
            System.out.println(e);
        }
    }

    public static void deleteAttendee(Scanner sc) {

        File eventsFile = new File("events.ser");
        if (!eventsFile.exists()) {
            try {
                wait("File doesn't exist, creating a new one...");
                eventsFile.createNewFile();
            } catch (IOException e) {
                System.out.println(e);
            }

        }

        try {

            HashMap<String, EventDetails> events = Serializer.deSerializeEvent(eventsFile);

            System.out.println("What is the event's name?");
            String eventName = sc.nextLine();

            for (Map.Entry<String, EventDetails> entry : events.entrySet()) {
                String key = entry.getKey();
                EventDetails value = entry.getValue();

                if (key.equalsIgnoreCase(eventName)) {

                    System.out.println("What is the attendee's name?");
                    String attendeeName = sc.nextLine();
                    ArrayList<Attendee> attendees = value.getAttendees();

                    for (Attendee attendee : attendees) {

                        if (attendee.getName() != null && attendee.getName().equalsIgnoreCase(attendeeName)) {
                            attendees.remove(attendee);
                            break;
                        }

                    }

                    events.put(key, new EventDetails(value.getEvent(), attendees));
                    Serializer.serializeEvent(eventsFile, events);

                    wait("Attendee has been deleted...");

                }
            }
        } catch (NullPointerException e) {
            System.out.println(e);
        }

    }

    public static void wait(String message) {

        try {
            System.out.println(message);
            Thread.sleep(400);
        } catch (InterruptedException e) {
            System.out.println(e);
        }

    }

    public static boolean keyChecker(HashMap<String, ?> hashin, String inpkey) {

        ArrayList<String> keylist = new ArrayList<>();

        for (Map.Entry<String, ?> entry : hashin.entrySet()) {

            String key = entry.getKey();

            try {
                keylist.add(key.toLowerCase());
            } catch (NullPointerException e) {
                System.out.println(e);
                return false;
            }

        }

        try {

            if (keylist.contains(inpkey.toLowerCase())) {

                return true;
            } else {

                return false;
            }
        } catch (NullPointerException e) {

            return false;
        }

    }

    public static ArrayList<String> getMapKeys(HashMap<String, ?> hashin) {

        ArrayList<String> keylist = new ArrayList<>();

        for (Map.Entry<String, ?> entry : hashin.entrySet()) {

            String key = entry.getKey();

            try {
                keylist.add(key.toLowerCase());
            } catch (NullPointerException e) {
                System.out.println(e);
                return keylist;
            }

        }

        return keylist;

    }

}
