package JavaAssessment;

import java.io.Serializable;

public class Attendee implements Serializable {

    private String name;
    private int age;
    private String email;
    private String number;

    // parameterised constuctor
    public Attendee(String name, int age, String email, String number) {

        this.name = name;
        this.age = age;
        this.email = email;
        this.number = number;
    }

    public Attendee(String name) {

        this.name = name;
    }

    public Attendee() {
    }

    // Getters

    public String getName() {

        return this.name;
    }

    public int getAge() {

        return this.age;
    }

    public String getEmail() {

        return this.email;
    }

    public String getNumber() {

        return this.number;
    }

    // Setters

    public void setName(String name) {

        this.name = name;
    }

    public void setAge(int age) {

        if (age < 0) {
            throw new IllegalArgumentException("Age cannot be negative");
        }

        this.age = age;
    }

    public void setEmail(String email) {

        this.email = email;
    }

    public void setNumber(String number) {

        this.number = number;
    }

}
