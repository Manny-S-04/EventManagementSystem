package JavaAssessment;

import java.io.Serializable;
import java.util.ArrayList;

public class EventDetails implements Serializable {

    private Event event;
    private ArrayList<Attendee> attendees;

    // constructors

    public EventDetails() {
    }

    public EventDetails(Event event) {

        this.event = event;

    }

    public EventDetails(Event event, ArrayList<Attendee> attendees) {

        this.event = event;
        this.attendees = attendees;

    }

    // getters

    public Event getEvent() {

        return this.event;
    }

    public ArrayList<Attendee> getAttendees() {

        return this.attendees;
    }

    // setters

    public void setEvent(Event event) {

        this.event = event;
    }

    public void setAttendees(ArrayList<Attendee> attendees) {

        this.attendees = attendees;
    }
}
