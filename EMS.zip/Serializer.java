package JavaAssessment;

import java.io.Serializable;
import java.util.HashMap;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Serializer implements Serializable {

    public static void serializeEvent(File newfile, HashMap<String, EventDetails> events) {

        try {

            FileOutputStream fout = new FileOutputStream(newfile);

            ObjectOutputStream oout = new ObjectOutputStream(fout);

            oout.writeObject(events);

            // close objects

            fout.close();
            oout.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + e);
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file: " + e);
        }

    }

    public static HashMap<String, EventDetails> deSerializeEvent(File file) {

        try {

            FileInputStream fin = new FileInputStream(file);

            ObjectInputStream oin = new ObjectInputStream(fin);


            HashMap<String, EventDetails> hashout = (HashMap<String, EventDetails>) oin.readObject();

            fin.close();
            oin.close();
            return hashout;
        } catch (IOException e) {
            System.out.println(e);
        } catch (ClassNotFoundException e) {
            System.out.println("Class not found");
            System.out.println(e);
        }

        return null;

    }

}

